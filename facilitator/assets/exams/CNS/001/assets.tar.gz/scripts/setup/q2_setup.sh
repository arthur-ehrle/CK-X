#!/bin/bash

# Create namespace if it doesn't exist
kubectl create namespace internal 

exit 0