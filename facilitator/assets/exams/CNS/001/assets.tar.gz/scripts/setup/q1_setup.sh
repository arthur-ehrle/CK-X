#!/bin/bash
# Setup script for Question 2: Docker container with port mapping and environment variables

# Ensure nginx:alpine image is available
docker pull httpd &> /dev/null

exit 0